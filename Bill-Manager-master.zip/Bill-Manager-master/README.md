# Bill-Manager
Splitwise Clone application using Javascript.

Application Features:
<ul>
  <li>Manage Friends (Add/Update/Delete)</li>
  <li>Manage Bills (Add/Update/Delete)</li>
  <li>Single Dashboard with details of Bills, Friends and Balances</li>
</ul>

Currently this code is only frontend code for managing bills with friends.
